# Interrupts
Invoke an interrupt with the `*` operator.
eg: `*0xbeef`


## Syscalls
Syscalls are a special case of an interrupt, accepting arguments and return types.
Adressed by name.
eg: `*write 1, "Hello, World!", 13`


**REMAINDER IS STILL WORK IN PROGRESS**

